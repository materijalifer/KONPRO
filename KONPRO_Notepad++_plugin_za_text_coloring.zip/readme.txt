Postupak za umetanje plugina:
Language -> Define your language -> Import -> erlang.xml
Restartati Notepad++

Svi erl fajlovi biti ce automatski prepoznati i obojani

Originalno preuzeto sa:
http://www.roberthorvick.com/2009/07/08/syntax-highlighing-for-erlang-in-notepad/